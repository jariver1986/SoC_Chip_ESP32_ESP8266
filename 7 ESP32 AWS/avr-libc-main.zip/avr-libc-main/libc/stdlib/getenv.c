#include <stdlib.h>

char *
getenv (const char *name)
{
  (void) name;
  return NULL;
}
